@push('scripts')
<script>
    const head = document.getElementsByTagName('head')[0];
    const isMobile = window.innerWidth <= 768;

    const preloadImage = (src) => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        head.appendChild(link);
    };

    // Preload sesuai device
    if (isMobile) {
        preloadImage('{{ asset("img/fajar-width-original.webp") }}');
    } else {
        preloadImage('{{ asset("img/fajar-width-original.webp") }}');
    }
</script>
@endpush
<header id="header">
    <div class="header-container-home" >
      <div id="logo" class="pull-left">
        <a href="{{ route('home') }}" class="scrollto" title="Logo Fajar Rental">
            <picture>
                <!-- Logo khusus mobile -->
                <source media="(max-width: 768px)" srcset="{{ asset('img/fajar-width-original.webp') }}">
                <!-- Logo default (desktop) -->
                <source media="(min-width: 769px)" srcset="{{ asset('img/fajar-width-original.webp') }}">
                <!-- Fallback -->
                <img src="{{ asset('img/fajar-width-original.webp') }}" alt="Logo Fajar Rental" loading="lazy">
            </picture>
        </a>
    </div>


    <nav id="nav-menu-container">
            <ul class="nav-menu">
              <li class="menu-active"><a href="{{ url('/') }}">BERANDA</a></li>
              <li><a href="{{ url('/armada') }}">ARMADA KAMI</a></li>
             <li><a href="{{ url('/pricelist') }}">PRICELIST</a></li>
             <li><a href="{{ url('/testimonial') }}">TESTIMONIAL</a></li>
              <li><a href="{{ url('/artikel') }}">ARTIKEL</a></li>
               <li class="dropdown">
                    <a href="javascript:void(0);" class="dropbtn" aria-label="dropdown opsi informasi">INFORMASI <i class="fa fa-chevron-down"></i></a>
                    <ul class="dropdown-content">
                         <li><a href="{{ url('/about-us') }}">
                           TENTANG KAMI
                        </a></li>
                        <li><a href="{{ url('/contact-us') }}">
                            KONTAK KAMI
                        </a></li>
                        <!-- Add other dropdown items here if needed -->
                    </ul>
                </li>

            </ul>
          </nav>

    </div>


  </header><!-- #header -->
