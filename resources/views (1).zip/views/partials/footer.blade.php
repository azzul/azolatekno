<div id="cookie-popup" class="cookie-popup hidden">
    <p class="cookie-text">
        Situs ini menggunakan cookie untuk meningkatkan pengalaman Anda. Dengan melanjutkan menggunakan situs, Anda menyetujui penggunaan cookie. 
        <a href="{{url('/privacy-policy')}}" class="cookie-link">Baca Kebijakan Privasi kami</a>.
    </p>
    <button id="accept-cookie" class="cookie-btn">Terima</button>
</div>

<footer id="footer">
  <div class="width_100 bg_image1" >
    <div class="footer-top">
    
      <div class="custom-container" style="padding-top: 0 !important;">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
           <picture>
                <!-- Logo khusus mobile -->
                <source media="(max-width: 768px)" srcset="{{ asset('img/fajar-width-original.webp') }}">
                <!-- Logo default (desktop) -->
                <source media="(min-width: 769px)" srcset="{{ asset('img/fajar-width-original.webp') }}">
                <!-- Fallback -->
                <img src="{{ asset('img/logo-fajarrent.webp') }}" alt="Logo Fajar Rental" loading="lazy">
            </picture>
            <div class="footer-contact">
            <p>Komplek Gading griya lestari Jl. Bringin IV blok AC 09_10 Sukapura, Cilincing, Jakarta utara <br>
              <strong>Telepon :</strong> 0818.084.1111.7<br>
              <strong>Whatsapp :</strong> 0811-920-939<br>
            </p>
            

            </div>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Tentang Fajar Rent Car</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="{{ url('/') }}">Beranda</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="{{ url('/about-us') }}">Tentang Kami</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="{{ url('/armada') }}">Armada Kami</a></li>
              
            </ul>
          </div>


          <div class="col-lg-3 col-md-6 footer-links">
    <h4>Paket Rental Mobil</h4>
    <ul>
    @foreach($footerCategory as $categoryFooter)
        <li>
            <i class="fa fa-angle-right"></i>

            <a href="{{ url('/armada/' . $categoryFooter->slug_produk )}}">
                {{$categoryFooter->nama_produk}}
            </a>
        </li>
    @endforeach
</ul>
</div>
          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Informasi</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="https://wa.me/62811920939?text=Halo%20Admin%20Fajar%20Rent%20Saya%20mau%20tanya%20cara%20sewa%20mobil%20yang%20ada%20di%20website.%20Saya%20dapat%20info%20dari%20https:/fajarrentcar.id" target="_blank" rel="nofollow noopener noreferrer">Cara Pesan</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="{{ url('/privacy-policy') }}">Kebijakan Privasi & cookie</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="{{ url('/terms-conditions') }}">Syarat Dan Ketentuan</a></li>
                <li><i class="fa fa-angle-right"></i> <a href="{{ url('/license-info') }}">Informasi Lisensi</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

    
      <div class="copyright">
        &copy; Copyright <strong>Fajar Rent Car</strong>. All Rights Reserved
      </div>
      <div class="credits">Designed by Azolatekno For <a href="https://fajarrentcar.id"><strong>fajarrentcar.id</strong></a>
      </div>
<!-- <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> -->
<a href="#" class="whatsapp-icon" id="whatsappIcon">
    <i class="fab fa-whatsapp"></i>
</a>

<div class="whatsapp-options" style="display: none;">
   <!--  <div class="whatsapp-option"><i class="fab fa-whatsapp"></i><p data-number="6281390095758">Marketing Kain area Jatim & Bali</p></div>
     <div class="whatsapp-option"><i class="fab fa-whatsapp"></i><p data-number="6281328379339">Marketing Kain area Jawa Tengah</p></div>
     <div class="whatsapp-option"><i class="fab fa-whatsapp"></i><p data-number="6281393734535">Marketing Kain area Jabodetabek</p></div>
     <div class="whatsapp-option"><i class="fab fa-whatsapp"></i><p data-number="6281393734535">Marketing Kain area Jabar</p></div> -->
     <div class="whatsapp-option"><i class="fab fa-whatsapp"></i><p data-number="62811920939">Marketing Kain, Makloon & Printing</p></div>
     <div class="whatsapp-option"><i class="fab fa-whatsapp"></i><p data-number="62811920939">Marketing Plastik Opp</p></div>
</div>
  </footer><!-- #footer -->


  <div class="bottom-navbar">
  <a href="{{ url('/') }}" >
    <i class="fa-solid fa-home"></i>
    Beranda
  </a>
  <div class="divider"></div>
  <a href="{{ url('/pricelist') }}">
    <i class="fas fa-book"></i>
    Pricelist
  </a>
  <div class="divider"></div>
  <a href="{{ url('/armada') }}">
    <i class="fas fa-car"></i>
    Armada
  </a>
  <div class="divider"></div>
  <a href="#" class="bottom-navbar-whatsapp" id="whatsappBottom">
    <i class="fa-brands fa-whatsapp"></i>
    Whatsapp
  </a>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W2N3FWS3"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

  