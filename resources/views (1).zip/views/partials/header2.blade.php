
<header id="header2">
    <div class="header-container-home" style="padding-top: 0 !important;">

      <div id="logo2" class="pull-left">
        <a href="{{ route('home') }}" class="scrollto"><img src="{{ asset('img/skrlogo.webp') }}" alt="Logo Sakura Sandang" title="Logo Sakura Sandang" loading='lazy'></a>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="{{ url('/') }}">BERANDA</a></li>
          <li><a href="{{ url('/about-us') }}">TENTANG KAMI</a></li>
         <li><a href="{{ url('/shop') }}">BELANJA</a></li>
          <li><a href="{{ url('/contact-us') }}">HUBUNGI KAMI</a></li>
           <li class="dropdown">
                <a href="javascript:void(0);" class="dropbtn" aria-label="dropdown opsi informasi">INFORMASI <i class="fa fa-chevron-down"></i></a>
                <ul class="dropdown-content">
                    <li><a href="{{ url('/pricelist') }}">
                       PRICELIST
                    </a></li>
                    <li><a href="{{ url('/katalog') }}">
                        KATALOG KAIN
                    </a></li>
                    <!-- Add other dropdown items here if needed -->
                </ul>
            </li>
            <li><a href="{{ url('/toko-bahan-kaos') }}">TOKO KAMI</a></li>
          <li class="language-option">
                <a href="#" class="dropdown-toggle"><i class="fas fa-globe"></i> ID</a>
                <div class="dropdown-language" style="display:none;">
                    <a href="{{ route('change-locale', ['lang' => 'id']) }}">Bahasa Indonesia</a>
                </div>
            </li>
        
    
        </ul>
      </nav><!-- #nav-menu-container -->
      <!-- data untuk search produk -->


     <div class="header-icons">

    <button href="javascript:void(0);" class="icon-language" id="customLanguageDropdownToggle" aria-label="Language">
    <i class="fas fa-globe"></i> ID
</button>

<!-- SEARCH FUNCTION -->
<div class="search-container">
    <button href="javascript:void(0);" class="icon icon-search" aria-label="Search" id="searchIcon">
        <i class="fas fa-search"></i>
    </button>
    <div class="search-bottom-sheet" id="searchBottomSheet">
        <div class="close-search-sheet-button" id="closeSearchSheet"><i class="fas fa-close"></i></div>
        <h4 class="search-title">Cari Produk</h4>
        <input type="text" id="searchInput" placeholder="Cari Produk..." />
        <div id="searchResultContainer" class="search-detail-sheet">
        </div>
    </div>
</div>

<div class="custom-dropdown" id="customLanguageDropdown">
    <a href="{{ route('change-locale', ['lang' => 'id']) }}" class="custom-dropdown-item">Indonesia</a>
    <!-- <a href="{{ url('/?lang=en') }}" class="custom-dropdown-item">English</a> -->
</div>
    
</div>
    </div>
  

  </header><!-- #header -->
