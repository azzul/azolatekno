@extends('layouts.app')
@push('scripts')
<script>
    const head = document.getElementsByTagName('head')[0];
    const isMobile = window.innerWidth <= 768;

    const preloadImage = (src) => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        head.appendChild(link);
    };

    if (isMobile) {
        preloadImage('{{ asset("img/main-mobile-bg.webp") }}');
    } else {
        preloadImage('{{ asset("img/bg-main.webp") }}');
    }
</script>
@endpush
@section('content')
<section id="intro">
    <div class="video-container">
        <!-- Initially display this image -->
        <picture>
            <!-- Source untuk layar kecil -->
            <source media="(max-width: 768px)" srcset="{{ asset('img/main-mobile-bg.webp') }}">
            
            <!-- Source default (untuk desktop) -->
            <source media="(min-width: 769px)" srcset="{{ asset('img/bg-main.webp') }}">

            <!-- Fallback untuk browser yang tidak support <picture> -->
            <img id="endImage" src="{{ asset('img/bg-main.webp') }}" class="endImage" alt="End Image" loading="lazy">
        </picture>main-mobile-bg.jpg
    </div>
    <div class="intro-container hide fadeIn">
    <h2 class="mb-4 pb-0 typed-text">KENYAMANAN <br><span>PERJALANAN ANDA</span> ADALAH PRIORITAS KAMI</h2>
    <h1 class="mb-4 pb-0 subtext show">Rental Mobil Jakarta dengan Sopir Mulai Rp 500 Ribu - Fajar Rent Car</h1>

    <div class="welcome-buttons">
    <a class="welcome-btn yuk-btn" href="https://altratex.com/shop">
        HUBUNGI KAMI <i class="fab fa-whatsapp"></i>
    </a>
</div>
</div>
</section>

<!-- <section id="home-main">
    <div class="custom-container pt-0 pb-0">
        <div class="flex-row-main">
          <div class="column-left-50">
            <div class="section-header-left">
              <h2>FAJAR RENT CAR</h2>
            </div>
            <p>
              Rental mobil terbaik se-jabodetabek! Kami melayani sewa mobil dengan harga dan mobil terbaik,
              dan tentunya supir terbaik juga! tertarik? langsung saja cek armada kami untuk memesan layanan kami
            </p>
            @php
                $phone = '62811920939';
                $message = "Halo admin fajar rent car, saya mau tanya sewa mobilnya. Saya dapat info dari " . url()->current();
                $whatsappLink = "https://wa.me/" . preg_replace('/[^0-9]/', '', $phone) . "?text=" . urlencode($message);
            @endphp
            <a class="btn-main mtop-20" href="{{ $whatsappLink }}" target="_blank" rel="nofollow noopener noreferrer"><i class="fab fa-whatsapp pr-10"></i>Hubungi Admin Kami</a>
          </div>
          <div class="column-right-50">
            <h2>FAJAR RENT CAR</h2>
            <img src="{{ asset('img/bg1.webp')}}" class="img-main-home" alt="Rental Mobil Jabodetabek">
          </div>
        </div>
    </div>
</section> -->
<section id="armada">
    <div class="custom-container">
        <div class="section-header">
            <h2>Pilihan Armada</h2>
        </div>
        <div class="product-grid">
            @foreach($products as $product)
                <div class="card-product">
                     <a href="{{ url('/armada/' . $product->slug_produk) }}" >
                    <img src="{{ asset('img/product/' . $product->image_produk)}}" alt="{{$product->nama_produk}}" loading="lazy">
                    <div class="product-content">
                        <p class="product-content-tittle ">{{$product->nama_produk}}</p>
                        @foreach ($product->harga as $harga)
                        <div class="description">{{ $harga->jenisHarga->jenis_harga }}</div>
                        <p class="product-content-price ">Rp {{ number_format($harga->harga, 0, ',', '.') }}</p>
                      @endforeach
                        
                        <div class="product-buttons">
                            @php
                                $phone = '62811920939';
                                $message = "Halo admin Fajar Rent Car, saya mau tanya " . $product->nama_produk . ". Saya dapat info dari " . url()->current();
                                $whatsappChat = "https://wa.me/" . preg_replace('/[^0-9]/', '', $phone) . "?text=" . urlencode($message);
                            @endphp
                                <a class="btn buy-btn" href="{{$whatsappChat}}" target="_blank" rel="nofollow noopener noreferrer">Hubungi Kami</a>
                                <!-- <button class="btn sample-btn">Sample Gratis</button> -->
                            </div>
                    </div>
                     </a>
                </div>
            @endforeach
        </div>
    </div>
</section>
<section id="home-main">
    <div class="custom-container pt-0 pb-0">
        <div class="flex-row-main">
          <div class="column-left-50">
            <div class="section-header-left">
              <h2>Mau Perjalanan Lebih Tenang dan Nyaman?</h2>
            </div>
            <p>
              Lelah menyetir sendiri di tengah macetnya Jakarta dan sekitarnya? Fajar Rent Car siap bantu Anda dengan layanan rental mobil lengkap dengan sopir profesional, aman, dan ramah. Cukup duduk santai, kami yang antar!
            </p>
            <p>
                📢 <strong>Unit terbatas, apalagi jelang weekend dan musim liburan cepat penuh!</strong>
            </p>
            @php
                $phone = '62811920939';
                $message = "Halo admin fajar rent car, saya mau tanya sewa mobilnya. Saya dapat info dari " . url()->current();
                $whatsappLink = "https://wa.me/" . preg_replace('/[^0-9]/', '', $phone) . "?text=" . urlencode($message);
            @endphp
            <a class="btn-main mtop-20" href="{{ $whatsappLink }}" target="_blank" rel="nofollow noopener noreferrer"><i class="fab fa-whatsapp pr-10"></i>Hubungi Kami Segera!</a>
          </div>
          <div class="column-right-50">
            <img src="{{ asset('img/rental-mobil-dengan-supir.webp')}}" class="img-main-home" alt="Rental Mobil Dengan Supir" loading="lazy">
          </div>
        </div>
    </div>
</section>
<section id="why-us">
    <div class="custom-container">
        <div class="section-header">
            <h2>Kenapa Sewa Mobil Di Fajar Rent Car?</h2>
            
        </div>
        <div class="why-us-content">

            <div class="why-us-item">
                <img src="{{ asset('img/icon/fleet.webp') }}" alt="Armada Lengkap" loading="lazy">
                <div class="why-us-info">
                    <h3>Pilihan Armada Lengkap</h3>
                    <p>Kami menyediakan berbagai jenis kendaraan, mulai dari city car hingga kendaraan premium, sesuai kebutuhan perjalanan Anda.</p>
                </div>
            </div>

            <div class="why-us-item">
                <img src="{{ asset('img/icon/comfort.webp') }}" alt="Nyaman & Bersih" loading="lazy">
                <div class="why-us-info">
                    <h3>Mobil Nyaman & Terawat</h3>
                    <p>Selalu dalam kondisi prima dengan perawatan rutin, memastikan kenyamanan dan keamanan selama perjalanan.</p>
                </div>
            </div>

            <div class="why-us-item">
                <img src="{{ asset('img/icon/driver.webp') }}" alt="Driver Berpengalaman" loading="lazy">
                <div class="why-us-info">
                    <h3>Driver Profesional & Ramah</h3>
                    <p>Jika memilih layanan dengan driver, kami menyediakan pengemudi berpengalaman yang siap melayani dengan ramah dan profesional.</p>
                </div>
            </div>

            <div class="why-us-item">
                <img src="{{ asset('img/icon/price-tag.webp') }}" alt="Harga Terjangkau" loading="lazy">
                <div class="why-us-info">
                    <h3>Harga Terjangkau</h3>
                    <p>Menawarkan harga yang kompetitif dengan berbagai pilihan paket sesuai kebutuhan perjalanan Anda.</p>
                </div>
            </div>

        </div>
    </div>
</section>

<section id="testimonial">
    <div class="custom-container">
        <div class="section-header-left mbottom-20 pb-20">
            <h2 style="text-align: center !important;">
                <i class="fas fa-chat"></i> REVIEW JUJUR PELANGGAN FAJAR RENT (GMAPS)
            </h2>
        </div>

        <div class="swiper-container swiper-container-testi">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="testimonial">
                        <div class="stars">★★★★★</div>
                        <p>"Mantap pelayanan nya. Banyak pilihan unit nya. Driver pengalaman dan bersih."</p>
                        <h4>- Very86 Magelang</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="testimonial">
                        <div class="stars">★★★★★</div>
                        <p>"Pengalaman pertama naik mobil fajar rent car sangat memuaskan, drivernya ramah² mobilnya wangi pokoknya next time kalau mau ke jkrt lagi pasti pake lagi🥰🥰🥰🥰"</p>
                        <h4>- Aji ST</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="testimonial">
                        <div class="stars">★★★★★</div>
                        <p>"Pengalaman pertama saya pakai jasa rental sangat puas🥰,driver ramah tau jalan mobil bersih wangi,,,,,next ke jakarta saya pake jasa rental ini lagi good job👍👍👍"</p>
                        <h4>- Upi Epul</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="testimonial">
                        <div class="stars">★★★★★</div>
                        <p>"Salah satu Rental terbaik di Jakarta...Driver ramah2...sopan unit bersih pokok e is the Best dah buat Fajar rent"</p>
                        <h4>- Fajar Sidiq</h4>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="testimonial">
                        <div class="stars">★★★★★</div>
                        <p>"pertama kali naik mobil fajar ren bagus drvernya ramah2 mobil bersih dan wangi"</p>
                        <h4>- Tawiyo Tawiyo</h4>
                    </div>
                </div>
            </div>
            <div class="swiper-pagination"></div>
            
        </div>
        <div class="flex-center">
            <div class="product-buttons">
                <a class="btn buy-btn mtop-20 mbottom-20" href="https://maps.app.goo.gl/4iM59F62MqjvZRYj6" target="_blank" rel="nofollow noopener noreferrer"><i class="fa-solid fa-map-pin mright-10"></i>Cek Google Maps</a>
            </div>
        </div>
    </div>
</section>


 
<script>
 
    // Pencarian produk dinamis
    document.addEventListener('DOMContentLoaded', function() {
        var mainTexts = [
            "DRIVER RAMAH <br><span>PERJALANAN</span> AMAN",
            "PILIHAN ARMADA <br><span>BERAGAM</span> DIJAMIN NYAMAN",
            "HARGA  <br><span>PALING TERJANGKAU</span> DI KELASNYA"
        ];

        var subTexts = [
            "Karena kepuasan pelanggan adalah kebanggaan kami.",
            "Dapatkan harga terbaik dengan belanja langsung dari pabrik.",
            "Kami memiliki tim laboratorium terbaik untuk memberikan warna dan kualitas kain terbaik untukmu.",
            ""
        ];

        var typed = new Typed('.typed-text', {
            strings: mainTexts,
            typeSpeed: 80, // Kecepatan mengetik
            backSpeed: 0, // Kecepatan menghapus teks (0 berarti tidak ada efek hapus)
            loop: true, // Tidak ada loop untuk menghindari animasi ulang
            showCursor: false, // Menyembunyikan kursor
            cursorChar: '|',
            onStringTyped: function(index) {},
            onComplete: function(self) {}
        });
    });


 

    
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    // Initialize Swiper for Testimonial with Auto-Slide
    const swiperTesti = new Swiper(".swiper-container-testi", {
        slidesPerView: "auto",
        spaceBetween: 20,
        freeMode: true,
        autoplay: {
            delay: 3000, // Ganti angka ini untuk mengatur kecepatan (ms)
            disableOnInteraction: false, // Tetap autoplay setelah user geser manual
        },
        loop: true, // Supaya looping terus tanpa berhenti
        breakpoints: {
            300: { slidesPerView: 1, spaceBetween: 10 },
            400: { slidesPerView: 1, spaceBetween: 15 },
            500: { slidesPerView: 1, spaceBetween: 15 },
            768: { slidesPerView: 2, spaceBetween: 20 },
            1024: { slidesPerView: 3, spaceBetween: 20 },
        },
    });

    // Custom button navigation for Testimonial
    const prevBtnTesti = document.getElementById("testi-prevBtn");
    const nextBtnTesti = document.getElementById("testi-nextBtn");

    if (prevBtnTesti && nextBtnTesti) {
        prevBtnTesti.addEventListener("click", function () {
            swiperTesti.slidePrev();
        });

        nextBtnTesti.addEventListener("click", function () {
            swiperTesti.slideNext();
        });
    }
});
</script>

<script>
    function openWhatsApp() {
        let phone = '62811920939';
        let message = "Halo admin Fajar Rent Car, saya mau tanya sewa mobilnya. Saya dapat info dari " + window.location.href;
        let whatsappLink = "https://wa.me/" + phone + "?text=" + encodeURIComponent(message);
        
        window.open(whatsappLink, "_blank");
    }
</script>
@endsection