@extends('layouts.app')

@push('json-ld')
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Beranda",
      "item": "{{ url('/') }}"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Tentang Kami",
      "item": "{{ url('/about-us') }}"
    }
  ]
}
</script>
@endpush
@push('scripts')
<script>

    if (isMobile) {
        preloadImage('{{ asset("img/about-us-mobile.webp") }}');
    } else {
        preloadImage('{{ asset("img/about-us.webp") }}');
    }
</script>
@endpush
@section('content')

    <!-- Navigasi Breadcrumb -->
    <section id="breadcrumb-section-about pt-90" >
        <div class="custom-container">
            <div class="breadcrumb-text">
                 <a href="{{ url('/') }}">Beranda</a> / 
                <span class="W-500">Tentang Kami</span>
            </div>
        </div>
    </section>

    <section class="about-us-section">
      <div class="custom-container ">
        <div class="flex-main-image">
            <picture>
            <!-- Source untuk layar kecil -->
            <source media="(max-width: 768px)" srcset="{{ asset('img/about-us-mobile.webp') }}">
            
            <!-- Source default (untuk desktop) -->
            <source media="(min-width: 769px)" srcset="{{ asset('img/about-us.webp') }}">

            <!-- Fallback untuk browser yang tidak support <picture> -->
            <img id="main-image" src="{{ asset('img/about-us.webp') }}" class="thumbnail-image" alt="Tentang Fajar Rent Car">
        </picture>
    </div>
        <div class="section-header">
  <h1>Tentang Fajar Rent Car</h1>
  <p></p>
</div>

<p class="about-description">
  <strong>Fajar Rent Car</strong> adalah layanan rental mobil terpercaya yang berlokasi di 
  <strong>Jl. Cempaka 1 Blok A4 No.2, Sukapura, Jakarta Utara</strong>. 
  Kami hadir untuk memberikan solusi transportasi yang mudah, aman, dan nyaman bagi masyarakat Jakarta dan sekitarnya.
  <br><br>
  Sejak berdiri, kami telah melayani berbagai kebutuhan perjalanan dengan sistem pemesanan online yang praktis. 
  Semua layanan kami disediakan bersama pengemudi berpengalaman, siap melayani Anda 24 jam nonstop.
  <br><br>
  Kami memiliki beragam pilihan armada, mulai dari MPV seperti Avanza, Xenia, Ertiga, Mobilio, Innova Reborn, 
  hingga kendaraan kelas premium seperti Fortuner, Pajero, Alphard, dan Camry. 
  Armada selalu dalam kondisi prima untuk memastikan kenyamanan dan keamanan setiap perjalanan Anda.
</p>

<p class="about-highlight">
  “Fajar Rent Car – Solusi Transportasi Andal, Nyaman, dan Profesional di Jakarta”
</p>

<div class="about-content">
  <div class="about-column">
    <h2>Visi Kami</h2>
    <p>
      Menjadi perusahaan rental mobil terpercaya dan unggul di Jakarta 
      dengan layanan prima, aman, dan memberikan nilai lebih bagi setiap pelanggan.
    </p>

    <h2>Misi Kami</h2>
    <ul>
      <li>Memberikan pengalaman sewa mobil yang mudah, cepat, dan nyaman melalui layanan online 24 jam.</li>
      <li>Menjaga kualitas armada agar selalu dalam kondisi bersih dan siap jalan.</li>
      <li>Menyediakan sopir profesional yang ramah dan memahami kebutuhan pelanggan.</li>
      <li>Menghadirkan harga kompetitif dengan fleksibilitas layanan sesuai kebutuhan pelanggan.</li>
      <li>Membangun kepercayaan dengan mengutamakan pelayanan yang jujur dan bertanggung jawab.</li>
      <li>Terus berinovasi untuk mengikuti perkembangan teknologi dan kebutuhan mobilitas masyarakat perkotaan.</li>
    </ul>
  </div>
</div>


    </section>

   <section id="why-us">
    <div class="custom-container">
        <div class="section-header">
            <h2>Kenapa Sewa Mobil Di Fajar Rent Car?</h2>
            
        </div>
        <div class="why-us-content">

            <div class="why-us-item">
                <img src="{{ asset('img/icon/fleet.webp') }}" alt="Armada Lengkap" loading="lazy">
                <div class="why-us-info">
                    <h3>Pilihan Armada Lengkap</h3>
                    <p>Kami menyediakan berbagai jenis kendaraan, mulai dari city car hingga kendaraan premium, sesuai kebutuhan perjalanan Anda.</p>
                </div>
            </div>

            <div class="why-us-item">
                <img src="{{ asset('img/icon/comfort.webp') }}" alt="Nyaman & Bersih" loading="lazy">
                <div class="why-us-info">
                    <h3>Mobil Nyaman & Terawat</h3>
                    <p>Selalu dalam kondisi prima dengan perawatan rutin, memastikan kenyamanan dan keamanan selama perjalanan.</p>
                </div>
            </div>

            <div class="why-us-item">
                <img src="{{ asset('img/icon/driver.webp') }}" alt="Driver Berpengalaman" loading="lazy">
                <div class="why-us-info">
                    <h3>Driver Profesional & Ramah</h3>
                    <p>Jika memilih layanan dengan driver, kami menyediakan pengemudi berpengalaman yang siap melayani dengan ramah dan profesional.</p>
                </div>
            </div>

            <div class="why-us-item">
                <img src="{{ asset('img/icon/price-tag.webp') }}" alt="Harga Terjangkau" loading="lazy">
                <div class="why-us-info">
                    <h3>Harga Terjangkau</h3>
                    <p>Menawarkan harga yang kompetitif dengan berbagai pilihan paket sesuai kebutuhan perjalanan Anda.</p>
                </div>
            </div>

        </div>
    </div>
</section>

    @endsection