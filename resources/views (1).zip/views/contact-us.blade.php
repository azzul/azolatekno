@extends('layouts.app')
@push('json-ld')
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Beranda",
      "item": "{{ url('/') }}"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Kontak Kami",
      "item": "{{ url('/contact-us') }}"
    }
  ]
}
</script>
@endpush
@section('content')
<section class="store-section-contact pt-90">
    <div class="container">
        <div class="section-header">
            <h1>Kontak Rental Mobil - Fajar Rent Car</h1>
        </div>
        <div class="store-card2">
            <div class="store-left">
                <h2 class="store-name text-center">FAJAR RENT CAR</h2>
                <p class="store-address text-center">Jl. Cempaka 1 blok A4 No.2 Sukapura, Jakarta Utara 14140</p>
             
                <div class="store-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.949906912045!2d106.9201002!3d-6.1374327!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e698ba4139a87ab%3A0x3795a07551453468!2sFAJAR%20RENT%20CAR!5e0!3m2!1sid!2sid!4v1745161459983!5m2!1sid!2sid" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
                
                <div class="store-buttons">
                    <a href="https://maps.app.goo.gl/nqY1gunYRJryfPjQ8" target="_blank" class="store-button" rel="nofollow noopener noreferrer">
                        <i class="fas fa-map-marker-alt"></i> Petunjuk Lokasi
                    </a>
                    <a href="https://wa.me/62811920939?text=Halo%20Fajar%20Rent%20Car,%20Saya%20mau%20tanya%20paket%20rental%20yang%20ada%20di%20website%20https://fajarrentcar.id" target="_blank" class="store-button" rel="nofollow noopener noreferrer">
                        <i class="fab fa-whatsapp"></i> Pesan WhatsApp
                    </a>
                </div>
            </div>
            <div class="store-right">
                <h3 class="operational-header text-center">Jam Operasional</h3>
                <ul class="operational-hours text-center">
                    <li>Senin - Minggu: 24 Jam</li>
                </ul>
                <h3 class="operational-header text-center">Whatsapp</h3>
                <p class="operational-hours text-center">+62811920939</p>
            </div>
        </div>
    </div>
</section>


@endsection